#! /usr/bin/env python3

from data import schema, seed

schema.schema()
seed.seed()
